export default function Header() {
	return (
		<div>
			<h1>Bieren</h1>
			<p>Er zijn veel bieren in België</p>
		</div>
	);
}
