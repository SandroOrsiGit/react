function Song({name}){

    
    return(
        <li>{name}</li>
    )
}
export default Song