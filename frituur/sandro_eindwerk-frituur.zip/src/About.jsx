export default function About() {
	const aboutStyle = {
		margin: "25px 300px",
	};
	return (
		<div style={aboutStyle}>
			<h1>Onze lekkere frituur</h1>
			<p>
				Lorem ipsum dolor sit amet consectetur adipisicing elit. Praesentium fugiat fuga nobis deserunt dolorem
				modi. Vero, qui, alias dolorem facilis aliquid accusantium debitis quibusdam maiores illum deleniti
				pariatur? Sunt eveniet quae unde quasi, accusantium odit quia. Autem minus repellat cupiditate sed quas
				vel similique, veniam, omnis explicabo deleniti culpa fugit iure molestiae error possimus, reiciendis ea
				architecto? Fuga at deserunt, odit inventore architecto eveniet. In fugit voluptatibus, tempora nesciunt
				omnis similique debitis harum molestias eos illo ea maxime sunt illum, est ut maiores voluptatum et
				repellendus saepe eum necessitatibus facere! Consequuntur nesciunt doloribus adipisci. Voluptatum
				assumenda quod quis dolore cumque.
			</p>
			<p>
				Lorem ipsum, dolor sit amet consectetur adipisicing elit. Aperiam cum assumenda reiciendis distinctio
				nam expedita neque reprehenderit perferendis rem adipisci voluptate ex autem ab recusandae similique
				necessitatibus cupiditate quia voluptatum nihil quo, deleniti tenetur facere. Dolores quis, cumque
				inventore rerum incidunt magnam? Voluptates perspiciatis incidunt, nihil dignissimos, illo excepturi,
				explicabo reprehenderit minus asperiores voluptatum dolor adipisci laborum aspernatur! Pariatur atque
				deserunt explicabo quidem iure? Atque vitae nobis distinctio error voluptatum illo sint maxime
				laudantium minus.
			</p>
			<p>
				Lorem ipsum dolor sit amet, consectetur adipisicing elit. Animi cum laboriosam dignissimos enim,
				repellendus minus. Ratione quos explicabo repellat amet accusantium, illum fugiat architecto, quis atque
				maxime, numquam tenetur adipisci? Tempore, cum. Sequi obcaecati aut quos ducimus, odio architecto ut.
				Harum, iste esse. Dolor explicabo reprehenderit totam tenetur vero placeat!
			</p>
		</div>
	);
}
